package com.sathyatel.calldetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MicroserviceCallDetailsApplicationTests {

	@Test
	public void contextLoads() {
	}

}
