package com.sathyatel.calldetails;

import org.junit.jupiter.api.Test;
import org.springframework.test.context.ContextConfiguration;

//@SpringBootTest
@ContextConfiguration
public class MicroservicePlanDetaislApplicationTests {

	@Test
	public void contextLoads() {
	}

}
