package com.sathyatel.friend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
//naresh
public class MicroserviceFriendsApplicationTests {

	@Test
	public void contextLoads() {
	}

}
