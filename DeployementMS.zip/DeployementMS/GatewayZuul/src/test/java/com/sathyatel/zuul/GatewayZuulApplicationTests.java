package com.sathyatel.zuul;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration
public class GatewayZuulApplicationTests {

	@Test
	public void contextLoads() {
	}

}
